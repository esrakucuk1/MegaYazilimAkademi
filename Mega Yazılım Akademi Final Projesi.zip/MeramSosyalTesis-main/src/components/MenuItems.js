export const MenuItems = [
  {
    title:"Anasayfa",
    url:"/",
    cname:"nav-links",
    icon:"fa-solid fa-house-user"
  },
  {
    title:"Hakkmızda",
    url:"/about",
    cname:"nav-links",
    icon:"fa-solid fa-circle-info"
  },
  {
    title:"Hizmetlerimiz",
    url:"/services",
    cname:"nav-links",
    icon:"fa-solid fa-briefcase"
  },
  {
    title:"İletişim",
    url:"/contact  ",
    cname:"nav-links",
    icon:"fa-solid fa-address-book"
  }
];
