import Cart from "../components/Layout/Cart/Cart";

const CardPage = () => {
  return <Cart />;
};

export default CardPage;
