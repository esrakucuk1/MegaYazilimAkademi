import Author from "../components/Layout/Author/Author";

const AuthPage = () => {
  return <Author />;
};

export default AuthPage;
