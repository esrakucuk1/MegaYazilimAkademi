import BlogDetails from "../components/Layout/BlogDetails/BlogDetails";

const BlogDetailsPage = () => {
  return (
    <>
      <BlogDetails />
    </>
  );
};

export default BlogDetailsPage;
