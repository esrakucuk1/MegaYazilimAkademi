import Contact from "../components/Layout/Contact/Contact";

const ContactPage = () => {
  return <Contact />;
};

export default ContactPage;
