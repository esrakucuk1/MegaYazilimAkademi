import Blogs from "../components/Layout/Blogs/Blogs";

const BlogPage = () => {
  return (
    <div className="blog-page">
      <Blogs />
    </div>
  );
};

export default BlogPage;
