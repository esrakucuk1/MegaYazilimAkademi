import React from "react";
import ProductDetails from "../components/Layout/Product-Details/ProductDetail";
const ProductDetailsPage = () => {
  return (
    <React.Fragment>
      <ProductDetails />
    </React.Fragment>
  );
};

export default ProductDetailsPage;
