const AdminLayout = () => {
  return <div>AdminLayout</div>;
};

export default AdminLayout;
