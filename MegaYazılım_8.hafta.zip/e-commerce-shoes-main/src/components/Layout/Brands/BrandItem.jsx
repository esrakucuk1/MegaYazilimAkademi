const BrandItem = () => {
  return (
    <li className="brand-item">
      <a href="#">
        <img src="/img/brands/brand2.png" alt="" />
      </a>
    </li>
  );
};

export default BrandItem;
